# 🛍️ Fluxo — Catálogo com Painel Admin

Site de catálogo de moda com painel admin visual e integração com WhatsApp.

---

## ✅ O que este projeto tem

- Catálogo bonito, fundo preto, estilo Fluxo Outlet
- Filtro por categoria
- Carrinho com pedido direto pelo WhatsApp
- Painel admin em `/admin` para adicionar/editar/deletar produtos
- Toggle para mostrar ou ocultar produtos sem deletar
- Tudo seu, hospedado de graça

---

## 🚀 Como colocar no ar (passo a passo)

### 1. Criar conta no GitHub
1. Acesse [github.com](https://github.com) e crie uma conta gratuita
2. Clique em **"New repository"**
3. Dê o nome `fluxo-catalogo`
4. Deixe **público** e clique em **Create repository**

### 2. Subir os arquivos
Na página do repositório criado, clique em **"uploading an existing file"** e arraste toda a pasta do projeto (menos a pasta `node_modules` se tiver).

Ou, se preferir pelo terminal:
```bash
cd fluxo-catalogo
git init
git add .
git commit -m "primeiro commit"
git remote add origin https://github.com/SEU_USUARIO/fluxo-catalogo.git
git push -u origin main
```

### 3. Criar conta na Vercel
1. Acesse [vercel.com](https://vercel.com)
2. Clique em **"Sign up"** e entre com sua conta do GitHub
3. Clique em **"New Project"**
4. Selecione o repositório `fluxo-catalogo`
5. Clique em **"Deploy"** — ele vai detectar Next.js automaticamente

### 4. Configurar as variáveis de ambiente (OBRIGATÓRIO)
Na Vercel, antes ou depois do deploy, vá em:
**Settings → Environment Variables** e adicione:

| Nome | Valor |
|------|-------|
| `ADMIN_PASSWORD` | Uma senha forte que só você sabe |
| `NEXT_PUBLIC_WHATSAPP` | Seu número: `5534991234567` |

Depois clique em **Redeploy** para aplicar.

### 5. Pronto! 🎉
Seu site estará em: `https://fluxo-catalogo.vercel.app`  
Painel admin em: `https://fluxo-catalogo.vercel.app/admin`

---

## 📱 Como usar o painel admin

1. Acesse `/admin` no seu site
2. Digite a senha que você configurou
3. Para **adicionar** produto: clique em "＋ Novo produto"
4. Para **editar**: clique no ✏️ ao lado do produto
5. Para **ocultar** sem deletar: use o toggle (botãozinho laranja)
6. Para **deletar**: clique em 🗑

> **Dica de imagem:** Use o site [imgur.com](https://imgur.com) — faça upload da foto e copie o link direto. Ou use o Google Drive com link público.

---

## 🤖 Como pedir para uma IA editar o site

Compartilhe o link do GitHub com a IA e diga:
> "Esse é meu site: [link do GitHub]. Quero que você [mudança desejada]."

A IA vai te dar o código alterado. Você cola no arquivo correto pelo GitHub e a Vercel atualiza automaticamente.

---

## 📞 Suporte
Qualquer dúvida, manda mensagem pelo WhatsApp ou abre uma conversa com uma IA explicando o que quer fazer.
