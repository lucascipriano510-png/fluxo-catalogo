/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['d2xsxph8kpxj0f.cloudfront.net'],
  },
}

module.exports = nextConfig
