import { useState, useEffect } from 'react'
import Head from 'next/head'

const fmt = (v) => `R$ ${Number(v).toFixed(2).replace('.', ',')}`

export default function Admin() {
  const [logado, setLogado] = useState(false)
  const [senha, setSenha] = useState('')
  const [token, setToken] = useState('')
  const [erroLogin, setErroLogin] = useState('')
  const [produtos, setProdutos] = useState([])
  const [loading, setLoading] = useState(false)
  const [modal, setModal] = useState(null) // null | 'novo' | produto
  const [form, setForm] = useState({ name: '', price: '', category: '', img: '', ativo: true })
  const [salvando, setSalvando] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => {
    const t = sessionStorage.getItem('fluxo_token')
    if (t) { setToken(t); setLogado(true); carregarProdutos(t) }
  }, [])

  async function login() {
    setErroLogin('')
    const r = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senha })
    })
    const d = await r.json()
    if (r.ok) {
      sessionStorage.setItem('fluxo_token', d.token)
      setToken(d.token); setLogado(true)
      carregarProdutos(d.token)
    } else {
      setErroLogin('Senha incorreta')
    }
  }

  async function carregarProdutos(t) {
    setLoading(true)
    const r = await fetch('/api/produtos')
    const d = await r.json()
    setProdutos(d)
    setLoading(false)
  }

  function abrirNovo() {
    setForm({ name: '', price: '', category: '', img: '', ativo: true })
    setModal('novo')
  }

  function abrirEditar(p) {
    setForm({ ...p })
    setModal(p)
  }

  async function salvar() {
    if (!form.name || !form.price || !form.img) {
      setMsg('Preencha nome, preço e URL da imagem')
      return
    }
    setSalvando(true)
    const isNovo = modal === 'novo'
    const r = await fetch('/api/produtos', {
      method: isNovo ? 'POST' : 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ ...form, price: parseFloat(String(form.price).replace(',', '.')) })
    })
    if (r.ok) {
      setMsg(isNovo ? 'Produto adicionado!' : 'Produto atualizado!')
      setModal(null)
      carregarProdutos(token)
    } else {
      setMsg('Erro ao salvar')
    }
    setSalvando(false)
    setTimeout(() => setMsg(''), 3000)
  }

  async function deletar(id) {
    if (!confirm('Deletar este produto?')) return
    await fetch(`/api/produtos?id=${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    })
    setProdutos(prev => prev.filter(p => p.id !== id))
    setMsg('Produto removido')
    setTimeout(() => setMsg(''), 3000)
  }

  async function toggleAtivo(p) {
    await fetch('/api/produtos', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ ...p, ativo: !p.ativo })
    })
    setProdutos(prev => prev.map(i => i.id === p.id ? { ...i, ativo: !i.ativo } : i))
  }

  function sair() {
    sessionStorage.removeItem('fluxo_token')
    setLogado(false); setToken(''); setProdutos([])
  }

  return (
    <>
      <Head>
        <title>Admin — Fluxo</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
      </Head>

      <style>{`
        body { background: #0a0a0a; color: #fff; font-family: 'Inter', sans-serif; min-height: 100vh; }
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        /* LOGIN */
        .login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .login-box { background: #141414; border: 1px solid #222; border-radius: 20px; padding: 40px 32px; width: 100%; max-width: 360px; text-align: center; }
        .login-logo { font-size: 2rem; font-weight: 900; color: #f5c518; margin-bottom: 4px; }
        .login-sub { font-size: 0.8rem; color: #555; margin-bottom: 32px; }
        .login-label { display: block; text-align: left; font-size: 0.78rem; color: #777; margin-bottom: 6px; font-weight: 600; letter-spacing: .05em; }
        .login-input { width: 100%; background: #1e1e1e; border: 1px solid #2a2a2a; border-radius: 10px; padding: 12px 14px; color: #fff; font-size: 0.95rem; margin-bottom: 16px; outline: none; }
        .login-input:focus { border-color: #f97316; }
        .login-btn { width: 100%; background: #f97316; color: #000; border: none; border-radius: 10px; padding: 13px; font-size: 0.95rem; font-weight: 800; transition: opacity .15s; }
        .login-btn:hover { opacity: .88; }
        .login-err { color: #ef4444; font-size: 0.8rem; margin-top: -8px; margin-bottom: 12px; }

        /* ADMIN LAYOUT */
        .adm-hdr { background: #111; border-bottom: 1px solid #1e1e1e; padding: 14px 20px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 10; }
        .adm-logo { font-size: 1.3rem; font-weight: 900; color: #f5c518; }
        .adm-logo-sub { font-size: 0.7rem; color: #555; font-weight: 400; margin-left: 8px; }
        .adm-right { display: flex; align-items: center; gap: 10px; }
        .btn-sair { background: #1e1e1e; border: none; color: #aaa; padding: 7px 14px; border-radius: 8px; font-size: 0.78rem; font-weight: 600; transition: all .15s; }
        .btn-sair:hover { background: #2a2a2a; color: #fff; }
        .btn-ver { background: #f97316; border: none; color: #000; padding: 7px 14px; border-radius: 8px; font-size: 0.78rem; font-weight: 700; }

        .adm-body { padding: 20px 16px 80px; max-width: 800px; margin: 0 auto; }

        /* STATS */
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 24px; }
        .stat { background: #141414; border: 1px solid #1e1e1e; border-radius: 12px; padding: 16px 14px; text-align: center; }
        .stat-val { font-size: 1.5rem; font-weight: 900; color: #f97316; }
        .stat-lbl { font-size: 0.7rem; color: #555; margin-top: 4px; }

        /* TOOLBAR */
        .toolbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
        .toolbar-title { font-size: 1rem; font-weight: 800; }
        .btn-add { background: #f97316; border: none; color: #000; padding: 10px 18px; border-radius: 10px; font-size: 0.82rem; font-weight: 800; display: flex; align-items: center; gap: 6px; transition: opacity .15s; }
        .btn-add:hover { opacity: .88; }

        /* LISTA */
        .prod-list { display: flex; flex-direction: column; gap: 10px; }
        .prod-item { background: #141414; border: 1px solid #1e1e1e; border-radius: 14px; padding: 14px; display: flex; align-items: center; gap: 14px; }
        .prod-img { width: 60px; height: 75px; object-fit: cover; object-position: top; border-radius: 8px; flex-shrink: 0; }
        .prod-img-placeholder { width: 60px; height: 75px; background: #1e1e1e; border-radius: 8px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }
        .prod-info { flex: 1; min-width: 0; }
        .prod-name { font-size: 0.9rem; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .prod-cat { font-size: 0.72rem; color: #555; margin-top: 2px; }
        .prod-price { font-size: 0.85rem; color: #f97316; font-weight: 700; margin-top: 4px; }
        .prod-actions { display: flex; flex-direction: column; gap: 6px; flex-shrink: 0; }
        .btn-edit { background: #1e1e1e; border: none; color: #aaa; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 600; transition: all .15s; }
        .btn-edit:hover { background: #2a2a2a; color: #fff; }
        .btn-del { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.2); color: #ef4444; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 600; transition: all .15s; }
        .btn-del:hover { background: rgba(239,68,68,.2); }
        .toggle { display: flex; align-items: center; gap: 6px; }
        .toggle-btn { width: 36px; height: 20px; border-radius: 10px; border: none; position: relative; cursor: pointer; transition: background .2s; flex-shrink: 0; }
        .toggle-btn.on { background: #f97316; }
        .toggle-btn.off { background: #333; }
        .toggle-dot { position: absolute; top: 3px; width: 14px; height: 14px; background: #fff; border-radius: 50%; transition: left .2s; }
        .toggle-dot.on { left: 19px; }
        .toggle-dot.off { left: 3px; }
        .toggle-label { font-size: 0.7rem; color: #555; }

        /* MODAL */
        .modal-ov { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,.8); display: flex; align-items: flex-end; }
        .modal-sheet { background: #141414; border-radius: 20px 20px 0 0; border-top: 1px solid #2a2a2a; width: 100%; max-height: 90vh; overflow-y: auto; padding: 24px 20px 40px; animation: sup .25s ease; }
        @keyframes sup { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .modal-hdr { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
        .modal-title { font-size: 1.1rem; font-weight: 800; }
        .modal-x { background: #2a2a2a; border: none; border-radius: 50%; width: 30px; height: 30px; color: #fff; font-size: .9rem; display: flex; align-items: center; justify-content: center; }
        .field { margin-bottom: 16px; }
        .field label { display: block; font-size: 0.78rem; color: #777; font-weight: 600; margin-bottom: 6px; letter-spacing: .04em; }
        .field input, .field select { width: 100%; background: #1e1e1e; border: 1px solid #2a2a2a; border-radius: 10px; padding: 12px 14px; color: #fff; font-size: 0.9rem; outline: none; }
        .field input:focus, .field select:focus { border-color: #f97316; }
        .field select option { background: #1e1e1e; }
        .img-preview { width: 100%; aspect-ratio: 3/2; object-fit: cover; border-radius: 10px; margin-top: 8px; background: #1e1e1e; }
        .btn-salvar { width: 100%; background: #f97316; color: #000; border: none; border-radius: 12px; padding: 15px; font-size: 1rem; font-weight: 800; margin-top: 8px; transition: opacity .15s; }
        .btn-salvar:hover { opacity: .88; }
        .btn-salvar:disabled { opacity: .5; }

        /* TOAST */
        .toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); background: #25d366; color: #000; padding: 12px 24px; border-radius: 12px; font-size: 0.85rem; font-weight: 700; z-index: 300; white-space: nowrap; }
        .loading { text-align: center; padding: 60px 0; color: #444; }
      `}</style>

      {!logado ? (
        <div className="login-wrap">
          <div className="login-box">
            <div className="login-logo">Fluxo</div>
            <div className="login-sub">Painel Administrativo</div>
            <label className="login-label">SENHA</label>
            <input
              className="login-input"
              type="password"
              placeholder="••••••••"
              value={senha}
              onChange={e => setSenha(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && login()}
            />
            {erroLogin && <p className="login-err">{erroLogin}</p>}
            <button className="login-btn" onClick={login}>Entrar</button>
          </div>
        </div>
      ) : (
        <>
          <header className="adm-hdr">
            <div>
              <span className="adm-logo">Fluxo</span>
              <span className="adm-logo-sub">Admin</span>
            </div>
            <div className="adm-right">
              <a href="/" target="_blank"><button className="btn-ver">Ver site →</button></a>
              <button className="btn-sair" onClick={sair}>Sair</button>
            </div>
          </header>

          <div className="adm-body">
            {/* STATS */}
            <div className="stats">
              <div className="stat">
                <div className="stat-val">{produtos.length}</div>
                <div className="stat-lbl">Produtos</div>
              </div>
              <div className="stat">
                <div className="stat-val">{produtos.filter(p => p.ativo).length}</div>
                <div className="stat-lbl">Ativos</div>
              </div>
              <div className="stat">
                <div className="stat-val">{new Set(produtos.map(p => p.category)).size}</div>
                <div className="stat-lbl">Categorias</div>
              </div>
            </div>

            {/* TOOLBAR */}
            <div className="toolbar">
              <div className="toolbar-title">Produtos</div>
              <button className="btn-add" onClick={abrirNovo}>＋ Novo produto</button>
            </div>

            {/* LISTA */}
            {loading ? (
              <div className="loading">Carregando...</div>
            ) : (
              <div className="prod-list">
                {produtos.map(p => (
                  <div key={p.id} className="prod-item">
                    {p.img
                      ? <img src={p.img} alt={p.name} className="prod-img" />
                      : <div className="prod-img-placeholder">👕</div>
                    }
                    <div className="prod-info">
                      <div className="prod-name">{p.name}</div>
                      <div className="prod-cat">{p.category}</div>
                      <div className="prod-price">{fmt(p.price)}</div>
                      <div className="toggle" style={{ marginTop: 8 }}>
                        <button
                          className={`toggle-btn ${p.ativo ? 'on' : 'off'}`}
                          onClick={() => toggleAtivo(p)}
                        >
                          <div className={`toggle-dot ${p.ativo ? 'on' : 'off'}`} />
                        </button>
                        <span className="toggle-label">{p.ativo ? 'Visível' : 'Oculto'}</span>
                      </div>
                    </div>
                    <div className="prod-actions">
                      <button className="btn-edit" onClick={() => abrirEditar(p)}>✏️ Editar</button>
                      <button className="btn-del" onClick={() => deletar(p.id)}>🗑 Deletar</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* MODAL PRODUTO */}
          {modal && (
            <div className="modal-ov" onClick={() => setModal(null)}>
              <div className="modal-sheet" onClick={e => e.stopPropagation()}>
                <div className="modal-hdr">
                  <span className="modal-title">{modal === 'novo' ? 'Novo Produto' : 'Editar Produto'}</span>
                  <button className="modal-x" onClick={() => setModal(null)}>✕</button>
                </div>

                <div className="field">
                  <label>NOME DO PRODUTO</label>
                  <input placeholder="Ex: Camiseta Branca" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div className="field">
                  <label>PREÇO (R$)</label>
                  <input type="number" placeholder="0.00" step="0.01" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
                </div>
                <div className="field">
                  <label>CATEGORIA</label>
                  <input placeholder="Ex: Camisetas, Calças, Jaquetas..." value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} />
                </div>
                <div className="field">
                  <label>URL DA IMAGEM</label>
                  <input placeholder="https://..." value={form.img} onChange={e => setForm(f => ({ ...f, img: e.target.value }))} />
                  {form.img && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={form.img} alt="preview" className="img-preview" onError={e => e.target.style.display='none'} />
                  )}
                </div>

                <button className="btn-salvar" onClick={salvar} disabled={salvando}>
                  {salvando ? 'Salvando...' : modal === 'novo' ? '+ Adicionar produto' : '✓ Salvar alterações'}
                </button>
              </div>
            </div>
          )}

          {msg && <div className="toast">{msg}</div>}
        </>
      )}
    </>
  )
}
