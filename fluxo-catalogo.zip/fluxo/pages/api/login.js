export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { senha } = req.body
  if (senha === process.env.ADMIN_PASSWORD) {
    return res.status(200).json({ ok: true, token: process.env.ADMIN_PASSWORD })
  }
  return res.status(401).json({ error: 'Senha incorreta' })
}
