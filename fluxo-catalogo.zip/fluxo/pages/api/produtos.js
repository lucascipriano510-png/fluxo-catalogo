import fs from 'fs'
import path from 'path'

const filePath = path.join(process.cwd(), 'lib', 'produtos.json')

function getProdutos() {
  const data = fs.readFileSync(filePath, 'utf-8')
  return JSON.parse(data)
}

function saveProdutos(produtos) {
  fs.writeFileSync(filePath, JSON.stringify(produtos, null, 2))
}

export default function handler(req, res) {
  if (req.method === 'GET') {
    const produtos = getProdutos()
    return res.status(200).json(produtos)
  }

  // Protege escrita com senha
  const { authorization } = req.headers
  if (authorization !== `Bearer ${process.env.ADMIN_PASSWORD}`) {
    return res.status(401).json({ error: 'Não autorizado' })
  }

  if (req.method === 'POST') {
    const produtos = getProdutos()
    const novo = { ...req.body, id: Date.now().toString(), ativo: true }
    produtos.push(novo)
    saveProdutos(produtos)
    return res.status(201).json(novo)
  }

  if (req.method === 'PUT') {
    const produtos = getProdutos()
    const idx = produtos.findIndex(p => p.id === req.body.id)
    if (idx === -1) return res.status(404).json({ error: 'Não encontrado' })
    produtos[idx] = { ...produtos[idx], ...req.body }
    saveProdutos(produtos)
    return res.status(200).json(produtos[idx])
  }

  if (req.method === 'DELETE') {
    let produtos = getProdutos()
    produtos = produtos.filter(p => p.id !== req.query.id)
    saveProdutos(produtos)
    return res.status(200).json({ ok: true })
  }

  res.status(405).end()
}
