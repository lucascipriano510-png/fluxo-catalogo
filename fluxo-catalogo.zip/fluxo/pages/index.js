import { useState } from 'react'
import Head from 'next/head'
import fs from 'fs'
import path from 'path'

const WHATSAPP = process.env.NEXT_PUBLIC_WHATSAPP || '5534999999999'
const fmt = (v) => `R$ ${Number(v).toFixed(2).replace('.', ',')}`

export async function getServerSideProps() {
  const filePath = path.join(process.cwd(), 'lib', 'produtos.json')
  const produtos = JSON.parse(fs.readFileSync(filePath, 'utf-8')).filter(p => p.ativo)
  return { props: { produtos } }
}

export default function Home({ produtos }) {
  const categorias = ['Todos', ...new Set(produtos.map(p => p.category))]
  const [cat, setCat] = useState('Todos')
  const [cart, setCart] = useState([])
  const [cartOpen, setCartOpen] = useState(false)
  const [zoom, setZoom] = useState(null)

  const filtered = cat === 'Todos' ? produtos : produtos.filter(p => p.category === cat)
  const totalQty = cart.reduce((s, i) => s + i.qty, 0)
  const totalVal = cart.reduce((s, i) => s + i.price * i.qty, 0)

  const addToCart = (p) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === p.id)
      if (ex) return prev.map(i => i.id === p.id ? { ...i, qty: i.qty + 1 } : i)
      return [...prev, { ...p, qty: 1 }]
    })
  }

  const changeQty = (id, delta) => {
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty: i.qty + delta } : i).filter(i => i.qty > 0))
  }

  const sendWhatsApp = () => {
    if (!cart.length) return
    const lines = cart.map(i => `• ${i.name} x${i.qty} — ${fmt(i.price * i.qty)}`).join('\n')
    const msg = `Olá! Quero fazer um pedido no Fluxo:\n\n${lines}\n\n*Total: ${fmt(totalVal)}*\n\nPor favor confirme disponibilidade! 🙏`
    window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, '_blank')
  }

  return (
    <>
      <Head>
        <title>Fluxo — Moda em 2 horas</title>
        <meta name="description" content="Catálogo Fluxo Outlet. Escolha, receba e pague. Tudo em até 2 horas em Uberaba." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
      </Head>

      <style>{`
        /* HEADER */
        .hdr {
          position: sticky; top: 0; z-index: 50;
          background: #0d0d0d; border-bottom: 1px solid #1e1e1e;
          padding: 14px 16px;
          display: flex; align-items: center; justify-content: space-between;
        }
        .hdr-logo { font-size: 1.6rem; font-weight: 900; color: #f5c518; line-height: 1; }
        .hdr-sub { font-size: 0.72rem; color: #777; margin-top: 1px; }
        .hdr-right { display: flex; align-items: center; gap: 10px; }
        .hdr-loc { display: flex; align-items: center; gap: 4px; font-size: 0.82rem; color: #bbb; }
        .hdr-cart {
          position: relative; background: #1e1e1e; border: none; border-radius: 10px;
          width: 40px; height: 40px; font-size: 1.1rem;
          display: flex; align-items: center; justify-content: center; transition: background .15s;
        }
        .hdr-cart:hover { background: #2a2a2a; }
        .hdr-badge {
          position: absolute; top: -4px; right: -4px;
          background: #f97316; color: #000; font-size: 0.58rem; font-weight: 900;
          width: 16px; height: 16px; border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
        }
        /* HERO */
        .hero {
          background: radial-gradient(ellipse at 50% 0%, #2d1500 0%, #0d0d0d 70%);
          padding: 36px 16px 32px; text-align: center;
        }
        .hero-wm { font-size: 3rem; font-weight: 900; font-style: italic; letter-spacing: -2px; color: #fff; text-shadow: 0 0 40px rgba(245,197,24,.25); margin-bottom: 2px; line-height: 1; }
        .hero-wm2 { font-size: 2rem; font-weight: 900; font-style: italic; letter-spacing: -1px; color: #fff; text-decoration: underline; text-underline-offset: 4px; margin-bottom: 28px; }
        .hero-h1 { font-size: 2.1rem; font-weight: 900; line-height: 1.1; margin-bottom: 10px; }
        .hero-h1 span { color: #f97316; }
        .hero-p { font-size: 0.92rem; color: #888; margin-bottom: 24px; }
        .feats { display: flex; flex-direction: column; gap: 10px; margin-bottom: 24px; }
        .feat { background: #181818; border: 1px solid #252525; border-radius: 12px; padding: 13px 14px; display: flex; align-items: center; gap: 12px; text-align: left; }
        .feat-ico { font-size: 1.3rem; flex-shrink: 0; }
        .feat-t { font-size: 0.87rem; font-weight: 700; }
        .feat-s { font-size: 0.73rem; color: #666; margin-top: 2px; }
        .explore-btn { width: 100%; background: #f97316; color: #000; border: none; border-radius: 14px; padding: 16px; font-size: 1rem; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px; transition: opacity .15s; }
        .explore-btn:hover { opacity: .88; }
        /* CATALOG */
        .catalog { padding: 24px 12px 100px; }
        .cat-scroll { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 12px; margin-bottom: 16px; scrollbar-width: none; }
        .cat-scroll::-webkit-scrollbar { display: none; }
        .pill { flex-shrink: 0; background: #1a1a1a; border: 1px solid #2a2a2a; color: #999; font-size: 0.78rem; font-weight: 600; padding: 7px 14px; border-radius: 20px; white-space: nowrap; transition: all .15s; }
        .pill:hover { border-color: #f97316; color: #f97316; }
        .pill.on { background: #f97316; border-color: #f97316; color: #000; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        /* CARD */
        .card { background: #181818; border: 1px solid #222; border-radius: 14px; overflow: hidden; }
        .card-img-wrap { position: relative; aspect-ratio: 3/4; overflow: hidden; cursor: zoom-in; }
        .card-img { width: 100%; height: 100%; object-fit: cover; object-position: top; display: block; transition: transform .4s; }
        .card-img-wrap:hover .card-img { transform: scale(1.06); }
        .price-tag { position: absolute; top: 8px; right: 8px; background: #f97316; color: #000; font-size: 0.72rem; font-weight: 800; padding: 4px 8px; border-radius: 8px; }
        .card-body { padding: 10px 10px 12px; }
        .card-name { font-size: 0.88rem; font-weight: 700; line-height: 1.2; margin-bottom: 2px; }
        .card-cat { font-size: 0.7rem; color: #555; margin-bottom: 10px; }
        .add-btn { width: 100%; background: #f97316; color: #000; border: none; border-radius: 10px; padding: 10px; font-size: 0.82rem; font-weight: 700; transition: opacity .15s, transform .1s; }
        .add-btn:hover { opacity: .88; }
        .add-btn:active { transform: scale(.97); }
        /* ZOOM */
        .zoom-ov { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,.92); display: flex; align-items: center; justify-content: center; flex-direction: column; padding: 20px; gap: 16px; }
        .zoom-img { max-width: 100%; max-height: 72vh; border-radius: 12px; object-fit: contain; }
        .zoom-close { position: absolute; top: 16px; right: 16px; background: #222; border: none; border-radius: 50%; width: 36px; height: 36px; color: #fff; font-size: 1rem; display: flex; align-items: center; justify-content: center; }
        .zoom-add { background: #f97316; color: #000; border: none; border-radius: 14px; padding: 14px 32px; font-size: 0.9rem; font-weight: 800; box-shadow: 0 4px 24px rgba(249,115,22,.35); }
        /* CART */
        .cart-ov { position: fixed; inset: 0; z-index: 100; background: rgba(0,0,0,.7); display: flex; align-items: flex-end; }
        .cart-sheet { background: #161616; border-radius: 20px 20px 0 0; border-top: 1px solid #2a2a2a; width: 100%; max-height: 85vh; display: flex; flex-direction: column; animation: sup .25s ease; }
        @keyframes sup { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .cart-hdr { display: flex; align-items: center; justify-content: space-between; padding: 20px 20px 14px; border-bottom: 1px solid #222; }
        .cart-title { font-size: 1.1rem; font-weight: 800; }
        .cart-x { background: #2a2a2a; border: none; border-radius: 50%; width: 30px; height: 30px; color: #fff; font-size: .9rem; display: flex; align-items: center; justify-content: center; }
        .cart-body { overflow-y: auto; flex: 1; padding: 12px 16px; }
        .empty { text-align: center; color: #444; padding: 40px 0; font-size: .9rem; }
        .ci { background: #1e1e1e; border-radius: 12px; padding: 12px 14px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
        .ci-name { font-size: .88rem; font-weight: 700; }
        .ci-price { font-size: .8rem; color: #f97316; font-weight: 600; margin-top: 2px; }
        .ci-sub { font-size: .72rem; color: #555; margin-top: 1px; }
        .ci-qty { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
        .qbtn { background: #2e2e2e; border: none; color: #fff; width: 28px; height: 28px; border-radius: 8px; font-size: 1rem; display: flex; align-items: center; justify-content: center; transition: background .15s; }
        .qbtn:hover { background: #f97316; color: #000; }
        .qnum { font-size: 1rem; font-weight: 700; min-width: 16px; text-align: center; }
        .cart-ft { padding: 14px 16px 24px; border-top: 1px solid #222; }
        .cart-tot { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px; }
        .tot-lbl { font-size: 1rem; font-weight: 700; }
        .tot-val { font-size: 1.4rem; font-weight: 900; color: #f97316; }
        .pay-note { font-size: .72rem; color: #555; text-align: center; margin-bottom: 14px; }
        .wpp-btn { width: 100%; background: #25d366; color: #000; border: none; border-radius: 14px; padding: 16px; font-size: 1rem; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; transition: opacity .15s; }
        .wpp-btn:hover { opacity: .88; }
      `}</style>

      {/* HEADER */}
      <header className="hdr">
        <div>
          <div className="hdr-logo">Fluxo</div>
          <div className="hdr-sub">Moda em 2 horas</div>
        </div>
        <div className="hdr-right">
          <div className="hdr-loc"><span>📍</span> Uberaba</div>
          <button className="hdr-cart" onClick={() => setCartOpen(true)}>
            🛍️
            {totalQty > 0 && <span className="hdr-badge">{totalQty}</span>}
          </button>
        </div>
      </header>

      {/* HERO */}
      <section className="hero">
        <div className="hero-wm">FLUXO</div>
        <div className="hero-wm2">OUTLET</div>
        <h1 className="hero-h1">Moda que<br /><span>flui com você</span></h1>
        <p className="hero-p">Escolha, receba e pague. Tudo em até 2 horas.</p>
        <div className="feats">
          <div className="feat"><span className="feat-ico">⏱️</span><div><div className="feat-t">Entrega em até 2 horas</div><div className="feat-s">Peça agora e receba hoje mesmo</div></div></div>
          <div className="feat"><span className="feat-ico">🔥</span><div><div className="feat-t">Looks exclusivos limitados</div><div className="feat-s">Coleções que mudam a cada semana</div></div></div>
          <div className="feat"><span className="feat-ico">✅</span><div><div className="feat-t">Confiado por centenas de clientes</div><div className="feat-s">Avaliações 5⭐ garantidas</div></div></div>
        </div>
        <button className="explore-btn" onClick={() => document.getElementById('cat').scrollIntoView({ behavior: 'smooth' })}>
          Explorar Looks →
        </button>
      </section>

      {/* CATALOG */}
      <section className="catalog" id="cat">
        <div className="cat-scroll">
          {categorias.map(c => (
            <button key={c} className={`pill${cat === c ? ' on' : ''}`} onClick={() => setCat(c)}>{c}</button>
          ))}
        </div>
        <div className="grid">
          {filtered.map(p => (
            <div key={p.id} className="card">
              <div className="card-img-wrap" onClick={() => setZoom(p)}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.img} alt={p.name} className="card-img" loading="lazy" />
                <span className="price-tag">{fmt(p.price)}</span>
              </div>
              <div className="card-body">
                <div className="card-name">{p.name}</div>
                <div className="card-cat">{p.category}</div>
                <button className="add-btn" onClick={() => addToCart(p)}>+ Adicionar</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ZOOM */}
      {zoom && (
        <div className="zoom-ov" onClick={() => setZoom(null)}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={zoom.img} alt={zoom.name} className="zoom-img" onClick={e => e.stopPropagation()} />
          <button className="zoom-close" onClick={() => setZoom(null)}>✕</button>
          <button className="zoom-add" onClick={() => { addToCart(zoom); setZoom(null); setCartOpen(true) }}>
            + Adicionar — {fmt(zoom.price)}
          </button>
        </div>
      )}

      {/* CART */}
      {cartOpen && (
        <div className="cart-ov" onClick={() => setCartOpen(false)}>
          <div className="cart-sheet" onClick={e => e.stopPropagation()}>
            <div className="cart-hdr">
              <span className="cart-title">Seu Carrinho</span>
              <button className="cart-x" onClick={() => setCartOpen(false)}>✕</button>
            </div>
            <div className="cart-body">
              {cart.length === 0
                ? <p className="empty">Seu carrinho está vazio.</p>
                : cart.map(item => (
                  <div key={item.id} className="ci">
                    <div>
                      <div className="ci-name">{item.name}</div>
                      <div className="ci-price">{fmt(item.price)} x {item.qty}</div>
                      <div className="ci-sub">Subtotal: {fmt(item.price * item.qty)}</div>
                    </div>
                    <div className="ci-qty">
                      <button className="qbtn" onClick={() => changeQty(item.id, -1)}>−</button>
                      <span className="qnum">{item.qty}</span>
                      <button className="qbtn" onClick={() => changeQty(item.id, 1)}>+</button>
                    </div>
                  </div>
                ))
              }
            </div>
            {cart.length > 0 && (
              <div className="cart-ft">
                <div className="cart-tot">
                  <span className="tot-lbl">Total:</span>
                  <span className="tot-val">{fmt(totalVal)}</span>
                </div>
                <p className="pay-note">* Você paga só o que ficar</p>
                <button className="wpp-btn" onClick={sendWhatsApp}>
                  💬 Enviar pedido pelo WhatsApp
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}
